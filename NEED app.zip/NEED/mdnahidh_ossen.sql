-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 10, 2023 at 07:36 AM
-- Server version: 5.7.42-cll-lve
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mdnahidh_ossen`
--

-- --------------------------------------------------------

--
-- Table structure for table `Login_info`
--

CREATE TABLE `Login_info` (
  `Id` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password_text` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Login_info`
--

INSERT INTO `Login_info` (`Id`, `Username`, `Password_text`) VALUES
(1, 'mdnahidhossen', 'mdn@hid(2003)'),
(2, 'nafiz123 ', 'nafiz123'),
(5, '1234 ', 'nafiz123'),
(6, '12345 ', 'nafiz123'),
(7, 'new ', 'new'),
(8, 'new1 ', 'new'),
(9, '', ''),
(10, 'hello ', 'hi');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `Id` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `First_name` varchar(50) NOT NULL,
  `Last_name` varchar(50) NOT NULL,
  `Profile_pic` varchar(200) DEFAULT NULL,
  `Bio_info` varchar(200) DEFAULT NULL,
  `Education_info` varchar(200) DEFAULT NULL,
  `Work_info` varchar(50) DEFAULT NULL,
  `Birthday` varchar(50) DEFAULT NULL,
  `Tag` varchar(1000) DEFAULT NULL,
  `Id_mode` varchar(50) DEFAULT NULL,
  `moblie_number` varchar(15) DEFAULT NULL,
  `Following` varchar(10000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`Id`, `Username`, `First_name`, `Last_name`, `Profile_pic`, `Bio_info`, `Education_info`, `Work_info`, `Birthday`, `Tag`, `Id_mode`, `moblie_number`, `Following`) VALUES
(1, 'mdnahidhossen', 'MD. Nahid', 'Hossen', NULL, 'Developer in Need', 'HABHIT', 'CEO of NEED', '19/11/2003', NULL, 'CEO', NULL, 'nafiz123 hello new'),
(2, 'nafiz123 ', 'Md Nafiz ', 'hossen ', NULL, NULL, NULL, NULL, '12/04/2012 ', NULL, NULL, '01590090217 ', 'new'),
(12, '1234', 'Md Nafiz ', 'hossen ', NULL, NULL, NULL, NULL, '12/04/2012 ', NULL, NULL, '01590090217 ', NULL),
(13, '12345 ', 'Md Nafiz ', 'hossen ', NULL, NULL, NULL, NULL, '12/04/2012 ', NULL, NULL, '01590090217 ', NULL),
(14, 'new ', 'new ', 'new ', NULL, NULL, NULL, NULL, '23/23/1234 ', NULL, NULL, '12345678901 ', NULL),
(15, 'new1 ', 'new ', 'new ', NULL, NULL, NULL, NULL, '23/23/1234 ', NULL, NULL, '12345678901 ', NULL),
(16, '', '', '', NULL, NULL, NULL, NULL, '', NULL, NULL, '', NULL),
(17, 'hello ', 'hi ', 'hello ', NULL, NULL, NULL, NULL, '12/03/2005 ', NULL, NULL, '01234567890 ', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Login_info`
--
ALTER TABLE `Login_info`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Login_info`
--
ALTER TABLE `Login_info`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
